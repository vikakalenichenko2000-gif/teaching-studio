# Журнал змін пам'яті

- 2026-11-10 — Отримано Teaching Studio (starter kit Lingo English School): інструкції, довідники ReadyTo/Wordwall/Quizlet/Baamboozle, бренд, шаблони, команди. Особисті дані попереднього викладача прибрано.
